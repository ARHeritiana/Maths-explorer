Deux éditions, mêmes sections. Compiler deux fois avec XeLaTeX : main.tex (guide enseignant), student.tex (notes étudiant). Les ateliers de la collection et leurs solutions sont inclus.
