Sources des six diaporamas. Les exports HTML sont assemblés par scripts/build-university.py dans le dépôt Maths Explorer.
