Sources des diaporamas de la collection. Les exports HTML sont assemblés par scripts/build-university.py dans le dépôt Maths Explorer.
