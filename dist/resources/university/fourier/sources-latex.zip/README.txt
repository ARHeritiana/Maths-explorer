Sources originales et quatre éditions LaTeX autonomes. Compiler chaque fichier .tex deux fois avec XeLaTeX.
