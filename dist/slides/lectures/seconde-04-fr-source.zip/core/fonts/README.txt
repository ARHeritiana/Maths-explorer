The fonts this theme loads by file name (named in core/mx-brand.sty: text, headings, STIX Two maths, Latin Modern Mono) are shared by all
sources and published once at sources/core/fonts/ on the site (with their licences). Copy that folder to core/fonts/ next to the
main file before compiling with XeTeX (xelatex -no-shell-escape), or set \mxcorepath to a folder that contains fonts/.
