The fonts this theme loads by file name (STIX Two text and maths, Schibsted Grotesk, Latin Modern Mono) are shared by all Maths Explorer
sources and published once at sources/core/fonts/ on the site (with their licences). Copy that folder to core/fonts/ next to the
main file before compiling with XeTeX (xelatex -no-shell-escape), or set \mxcorepath to a folder that contains fonts/.
